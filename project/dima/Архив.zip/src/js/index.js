import jQuery from "jquery";
import popper from "popper.js";
import bootstrap from "bootstrap";
import bsCustomFileInput from "bs-custom-file-input";
import select from "select2/dist/js/select2.full.min";

window.jQuery = jQuery;
var $ = jQuery;

$(function() {
  $(document).ready(function() {
    //select
    $(".js-example-basic-single").select2({
      theme: "bootstrap",
      dropdownCssClass: "dropdownContainer",
      minimumResultsForSearch: -1
    });
    $("#selectLang").select2({
      adaptContainerCssClass: "selectLangContainer",
      theme: "bootstrap",
      containerCssClass: "selectLang",
      dropdownCssClass: "dropdownSelectLang",
      minimumResultsForSearch: -1
    });
    $('[class*="icon-eye"]').each(function(index, node) {
      let $this = $(this);
      $(this)
        .parent()
        .click(function(e) {
          if (e.target.closest(".top-nav_list-link") != undefined) {
            $this.toggleClass("d-none");
          }
        });
    });
    //file-input
    (function fileInput() {
      bsCustomFileInput.init();
      $("body").on("DOMSubtreeModified", ".custom-file-label", function(_this) {
        $(this)
          .parent()
          .find(".reset")
          .addClass("active");
        $(this)
          .parent()
          .addClass("active");

        var _this = $(this);
        $(this)
          .parent()
          .find(".reset")
          .click(function() {
            _this.text("");
            $(this).removeClass("active");
            $(this)
              .parent()
              .removeClass("active");
          });
      });
    })();
  });
});
